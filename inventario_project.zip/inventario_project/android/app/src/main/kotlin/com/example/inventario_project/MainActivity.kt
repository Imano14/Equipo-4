package com.example.inventario_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
