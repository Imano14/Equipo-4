import 'package:flutter/material.dart';
import 'signup.dart';
import 'login2.dart';
import 'tabla_movie.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Inventario App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: LoginPage.id,
      routes: {
        LoginPage.id: (context) => LoginPage(),
        Singup.id: (context) => Singup(),
        //TablaMovie.id: (context) => TablaMovie(),
        '/tabla': (context) => TablaProductPage(),
      },
    );
  }
}
